namespace WebApi.Entities;

using Google.Protobuf.WellKnownTypes;
using System.Collections.Generic;
using System.Text.Json.Serialization;

public class User
{
    public string Username { get; set; }

    public string Password { get; set; }
    public List<User> ListUser { get; internal set; }
    public int UserCount { get; internal set; }
    public string History { get; internal set; }
    public DateTime Timestamp { get; set; }

}