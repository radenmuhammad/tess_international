namespace WebApi.Models;

using System.ComponentModel.DataAnnotations;

public class EditUpdateModel
{
    [Required]
    public string Username { get; set; }

    public string Password { get; set; }

    public string UsernameSession { get; set; }

}
