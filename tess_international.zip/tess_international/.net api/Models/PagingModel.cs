﻿namespace WebApi.Models
{
    public class PagingModel
    {
        public int Page { get; set; }

        public string UsernameSession { get; set; }

    }
}
