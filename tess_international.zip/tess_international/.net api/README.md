# dotnet-6-basic-authentication-api

.NET 6.0 - Basic HTTP Authentication API

Documentation at https://jasonwatmore.com/post/2021/12/20/net-6-basic-authentication-tutorial-with-example-api