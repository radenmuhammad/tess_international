﻿namespace WebApi.Controllers;

using Microsoft.AspNetCore.Mvc;
using WebApi.Authorization;
using WebApi.Models;
using WebApi.Services;

[Authorize]
[ApiController]
[Route("[controller]")]
public class UsersController : ControllerBase
{
    private IUserService _userService;

    public UsersController(IUserService userService)
    {
        _userService = userService;
    }

    [AllowAnonymous]
    [HttpPost("authenticate")]
    public async Task<IActionResult> Authenticate([FromBody] AuthenticateModel model)
    {
        var user = await _userService.Authenticate(model.Username, model.Password);

        if (user == null)
            return BadRequest(new { message = "Username or password is incorrect" });

        return Ok(user);
    }

    [AllowAnonymous]
    [HttpPost("paging")]
    public async Task<IActionResult> Paging([FromBody] PagingModel model)
    {
        var user = await _userService.Paging(model.Page);
        return Ok(user);
    }

    [AllowAnonymous]
    [HttpPost("submit")]
    public async Task<IActionResult> Submit([FromBody] AuthenticateModel model)
    {
        var user = await _userService.Submit(model.UsernameSession, model.Username, model.Password);

        return Ok(user);
    }
    // editUrl
    [AllowAnonymous]
    [HttpPost("edit")]
    public async Task<IActionResult> Edit([FromBody] EditUpdateModel model)
    {
        var user = await _userService.Edit(model.UsernameSession, model.Username,model.Password);

        return Ok(user);
    }

    [AllowAnonymous]
    [HttpPost("delete")]
    public async Task<IActionResult> Delete([FromBody] EditUpdateModel model)
    {
        var user = await _userService.Delete(model.UsernameSession, model.Username);

        return Ok(user);
    }

    [AllowAnonymous]
    [HttpPost("logout")]
    public async Task<IActionResult> Logout([FromBody] EditUpdateModel model)
    {
        var user = await _userService.Logout(model.UsernameSession);

        return Ok(user);
    }

    [AllowAnonymous]
    [HttpPost("loadAuditTrailData")]
    public async Task<IActionResult> loadAuditTrailData([FromBody] EditUpdateModel model)
    {
        var user = await _userService.loadAuditTrailData(model.UsernameSession);

        return Ok(user);
    }

}
