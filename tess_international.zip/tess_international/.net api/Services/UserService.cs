namespace WebApi.Services;

using MySql.Data.MySqlClient;
using WebApi.Entities;
using MySql.Data.Types;
using MySqlX.XDevAPI;
using Microsoft.Data.SqlClient;
using System.Drawing;
using MySqlX.XDevAPI.Common;
using Microsoft.Data.Sql;
using System.Data;
using System.Reflection.Metadata.Ecma335;
using System.Net.NetworkInformation;
using Google.Protobuf.Collections;
using System.Runtime.CompilerServices;

public interface IUserService
{
    Task<User> Authenticate(string username, string password);
    Task<User> Delete(string usernameSession, string username);
    Task<User> Edit(string usernameSession, string username, string password);
    Task<User> loadAuditTrailData(string usernameSession);
    Task<User> Logout(string usernameSession);
    Task<User> Paging(int page);
    Task<User> Submit(string usernameSession, string username, string password);
}

public class UserService : IUserService
{
    // for mysql server connection
    String myConnectionString = "server=127.0.0.1;uid=root;pwd=;database=tess_international";
    // for sql server connection
    String sqlConnetionString = "Server=localhost;Database=tess_international;Integrated Security=True;TrustServerCertificate=True;MultipleActiveResultSets=true;";
    int sizeOfPage = 10;

    public Task<User> Authenticate(string username, string password)
    {
        User user = new User();
        //sql server ways
        SqlConnection sqlconn = new SqlConnection(sqlConnetionString);
        SqlCommand myCommand = new SqlCommand("SELECT TOP 1 username,password " +
            "                                  FROM users WHERE username='" + username + "' " +
            "                                  AND password=CONVERT(VARCHAR(32), HashBytes('MD5', '" + password + "'), 2)", sqlconn);
        SqlCommand myCommandSelectAll = new SqlCommand("SELECT TOP " + sizeOfPage + " username,password " +
            "                                  FROM users", sqlconn);
        SqlCommand mySelectCountAll = new SqlCommand("SELECT COUNT(*) / " + sizeOfPage + " AS TotalUsers " +
            "                                  FROM users", sqlconn);
        SqlCommand auditTrailCommand = new SqlCommand("INSERT INTO auditTrail (history,username,timestamp) " +
            "                                  VALUES('" + username + " has already logged in','" + username + "',CURRENT_TIMESTAMP)", sqlconn);

        sqlconn.Open();
        auditTrailCommand.ExecuteReader();
        Boolean isLogin = false;
        using (var rdr = myCommand.ExecuteReader())
        {
            if (rdr.Read())
            {
                user.Username = rdr.GetString(rdr.GetOrdinal("username")).TrimEnd();
                user.Password = rdr.GetString(rdr.GetOrdinal("password")).TrimEnd();
                List<User> lists = new List<User>();
                using (var rdr2 = myCommandSelectAll.ExecuteReader())
                {
                    while (rdr2.Read())
                    {
                        User allUsers = new User();
                        allUsers.Username = rdr2.GetString(rdr2.GetOrdinal("username")).TrimEnd();
                        allUsers.Password = rdr2.GetString(rdr2.GetOrdinal("password")).TrimEnd();
                        lists.Add(allUsers);
                    }
                }
                using (var rdr3 = mySelectCountAll.ExecuteReader())
                {
                    while (rdr3.Read())
                    {
                        user.UserCount = rdr3.GetInt32(rdr3.GetOrdinal("TotalUsers"));
                    }
                }
                user.ListUser = lists;
                isLogin = true;
            }
        }
        if (!isLogin)
        {
            user = null;
        }
        sqlconn.Close();
        /*
        //mysql server ways
        MySqlConnection mysqlConn = new MySqlConnection(myConnectionString);
        MySql.Data.MySqlClient.MySqlCommand myCommand = new MySql.Data.MySqlClient.MySqlCommand("SELECT `username`,`password` FROM `users` WHERE `username`='"+username+ "' AND `password`= MD5('" + password+"')", conn);
        mysqlConn.open();
        MySqlDataReader rdr = myCommand.ExecuteReader();
        Boolean isLogin = false;
        while (rdr.Read())
        {
            user.Username = (string)rdr[0];
            user.Password = (string)rdr[1];
            isLogin = true;
        }
        if (!isLogin) {
            user = null;
        }
        rdr.Close();
        mysqlConn.Close();
        */
        return Task.FromResult(user);
    }

    public Task<User> Paging(int paging)
    {
        User user = new User();
        //sql server ways
        SqlConnection sqlconn = new SqlConnection(sqlConnetionString);
        SqlCommand myCommandSelectAll = new SqlCommand("SELECT username,password FROM users ORDER BY username OFFSET " + (paging-1)+" ROWS FETCH NEXT 1 ROWS ONLY", sqlconn);
        SqlCommand mySelectCountAll = new SqlCommand("SELECT COUNT(*) / " + sizeOfPage + " AS TotalUsers " +
            "                                  FROM users", sqlconn);
        sqlconn.Open();
        List<User> lists = new List<User>();
        using (var rdr2 = myCommandSelectAll.ExecuteReader())
        {
            while (rdr2.Read())
            {
                User allUsers = new User();
                allUsers.Username = rdr2.GetString(rdr2.GetOrdinal("username")).TrimEnd();
                allUsers.Password = rdr2.GetString(rdr2.GetOrdinal("password")).TrimEnd();
                lists.Add(allUsers);
            }
        }
        using (var rdr3 = mySelectCountAll.ExecuteReader())
        {
            while (rdr3.Read())
            {
                user.UserCount = rdr3.GetInt32(rdr3.GetOrdinal("TotalUsers"));
            }
        }
        user.ListUser = lists;
        sqlconn.Close();
        return Task.FromResult(user);
    }

    public Task<User> Submit(string usernameSession, string username, string password)
    {
        //sql server ways
        SqlConnection sqlconn = new SqlConnection(sqlConnetionString);
        SqlCommand auditTrailCommand = new SqlCommand("INSERT INTO auditTrail (history,username,timestamp) " +
            "                                  VALUES('" + usernameSession + " has already submitted the data with username=" + username + " and password=" + password + "','" + usernameSession + "',CURRENT_TIMESTAMP)", sqlconn);
        SqlCommand myCommandSelectAll = new SqlCommand("INSERT INTO users (username,password) VALUES ('"+ username + "',CONVERT(VARCHAR(32), HashBytes('MD5', '" + password + "'), 2));", sqlconn);
        sqlconn.Open();
        myCommandSelectAll.ExecuteReader();
        auditTrailCommand.ExecuteReader();
        sqlconn.Close();
        return this.Paging(1);
    }

    public Task<User> Edit(string usernameSession, string username,string password)
    {
        //sql server ways
        SqlConnection sqlconn = new SqlConnection(sqlConnetionString);
        SqlCommand auditTrailCommand = new SqlCommand("INSERT INTO auditTrail (history,username,timestamp) " +
            "                                  VALUES('" + usernameSession + " has already updated the data with username=" + username + " and password=" + password + "','" + usernameSession + "',CURRENT_TIMESTAMP)", sqlconn);
        SqlCommand myCommandSelectAll = new SqlCommand("UPDATE users SET password=CONVERT(VARCHAR(32), HashBytes('MD5', '" + password + "'), 2) WHERE username='" + username + "'", sqlconn);
        sqlconn.Open();
        auditTrailCommand.ExecuteReader();
        myCommandSelectAll.ExecuteReader();
        sqlconn.Close();
        return this.Paging(1);
    }

    public Task<User> Delete(string usernameSession, string username)
    {
        //sql server ways
        SqlConnection sqlconn = new SqlConnection(sqlConnetionString);
        SqlCommand auditTrailCommand = new SqlCommand("INSERT INTO auditTrail (history,username,timestamp) " +
            "                                  VALUES('" + usernameSession + " has already deleted the data with username=" + username + "','" + usernameSession + "',CURRENT_TIMESTAMP)", sqlconn);
        SqlCommand myCommandSelectAll = new SqlCommand("DELETE FROM users WHERE username='" + username + "'", sqlconn);
        sqlconn.Open();
        auditTrailCommand.ExecuteReader();
        myCommandSelectAll.ExecuteReader();
        sqlconn.Close();
        return this.Paging(1);
    }

    public Task<User> Logout(string usernameSession)
    {
        SqlConnection sqlconn = new SqlConnection(sqlConnetionString);
        SqlCommand auditTrailCommand = new SqlCommand("INSERT INTO auditTrail (history,username,timestamp) " +
            "                                  VALUES('" + usernameSession + " has already log out','" + usernameSession + "',CURRENT_TIMESTAMP)", sqlconn);
        sqlconn.Open();
        auditTrailCommand.ExecuteReader();
        sqlconn.Close();
        return this.Paging(1);
    }

    public Task<User> loadAuditTrailData(string usernameSession)
    {
        User user = new User();
        SqlConnection sqlconn = new SqlConnection(sqlConnetionString);
        SqlCommand auditTrailSelectCommand = new SqlCommand("SELECT * FROM auditTrail WHERE username='"+ usernameSession + "'", sqlconn);
        List<User> lists = new List<User>();
        Boolean isLogin = false;
        sqlconn.Open();
        using (var rdr2 = auditTrailSelectCommand.ExecuteReader())
        {
            while (rdr2.Read())
            {
                User allUsers = new User();
                allUsers.History = rdr2.GetString(rdr2.GetOrdinal("history")).TrimEnd();
                allUsers.Username = rdr2.GetString(rdr2.GetOrdinal("username")).TrimEnd();
                allUsers.Timestamp = rdr2.GetDateTime(rdr2.GetOrdinal("timestamp"));
                lists.Add(allUsers);
                isLogin = true;
            }
        }
        if (!isLogin)
        {
            user = null;
        }
        user.ListUser = lists;
        return Task.FromResult(user);
    }
}
